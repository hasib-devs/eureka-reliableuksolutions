<?php $this->load->view('header/header'); ?>
<?php $this->load->view('navbar/navbar'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Staff / Employee Payments</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>Dashboard">Dashboard</a></li>
              <li class="breadcrumb-item active">Staff / Employee Payments</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <?php
    $exception = $this->session->userdata('exception');
    if(isset($exception))
    {
    echo $exception;
    $this->session->unset_userdata('exception');
    } ?>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Staff / Employee Payment Lists</h3>
                <a href="<?php echo site_url(); ?>newempPayment" class="btn btn-primary" style="float: right" ><i class="fa fa-plus"></i> New Payment</a>
              </div>

              <div class="card-body">
                <table id="example" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th>#SN.</th>
                      <th>Name</th>
                      <th>ID</th>
                      <th>Date</th>
                      <th>Salary</th>
                      <th>Attendance</th>
                      <th>Advance</th>
                      <th>Payment</th>
                      <th>Note</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $i = 0;
                    foreach ($employees as $key => $value) {
                    $i++;
                    ?>
                    <tr class="gradeX">
                      <td><?php echo $i; ?></td>
                      <td><?php echo $value['empName']; ?></td>
                      <td><?php echo $value['empCode']; ?></td>
                      <td>
                        <?php
                        $month = $value['month'];
                        if($month == 01)
                          {
                          $name = 'January';
                          }
                        else if($month == 02)
                          {
                          $name = 'February';
                          }
                        else if($month == 03)
                          {
                          $name = 'March';
                          }
                        else if($month == 04)
                          {
                          $name = 'April';
                          }
                        else if($month == 05)
                          {
                          $name = 'May';
                          }
                        else if($month == 06)
                          {
                          $name = 'June';
                          }
                        else if($month == 07)
                          {
                          $name = 'July';
                          }
                        else if($month == 8)
                          {
                          $name = 'August';
                          }
                        else if($month == 9)
                          {
                          $name = 'September';
                          }
                        else if($month == 10)
                          {
                          $name = 'October';
                          }
                        else if($month == 11)
                          {
                          $name = 'November';
                          }
                        else
                          {
                          $name = 'December';
                          }
                        ?>
                        <?php echo $name.' '.$value['year']; ?>
                      </td>
                      <td><?php echo number_format($value['salary'], 2) ?></td>
                      <td><?php echo $value['attday']; ?></td>
                      <td><?php echo number_format($value['aAmount'], 2) ?></td>
                      <td><?php echo number_format($value['pAmount'], 2) ?></td>
                      <td><?php echo $value['note']; ?></td>
                      <td>
                        <a class="btn btn-success btn-xs" href="<?php echo site_url().'empPaymentDetails/'.$value['epid'] ?>" ><i class="fa fa-eye"></i></a>
                        <a class="btn btn-danger btn-xs" href="<?php echo site_url('Employee_payment/delete_employee_payment').'/'.$value['epid']; ?>" onclick="return confirm('Are you sure you want to delete this Payment ?');" ><i class="fa fa-trash"></i></a>
                      </td>
                    </tr>   
                    <?php } ?> 
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

<?php $this->load->view('footer/footer'); ?>